from app import settings
from .base import BaseSmsProvider


class SecondarySmsApiProvider:
    """
    Secondary SMS API Provide
    Write this class from scratch based on `primary.py` and `old.py` files
    """
    #
    # @TODO: Implement it
    #
