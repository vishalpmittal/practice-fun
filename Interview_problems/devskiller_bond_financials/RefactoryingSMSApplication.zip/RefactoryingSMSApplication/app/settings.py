PRIMARY_API_KEY = 'alice'
SECONDARY_API_KEY = 'bob'
COUNTRY_CODES = {
    'PL': '0048',
    'DE': '0049',
}
