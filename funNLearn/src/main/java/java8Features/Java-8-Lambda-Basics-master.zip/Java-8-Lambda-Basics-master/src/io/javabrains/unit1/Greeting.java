package io.javabrains.unit1;

@FunctionalInterface
public interface Greeting {
	public void perform();
	
	


}
