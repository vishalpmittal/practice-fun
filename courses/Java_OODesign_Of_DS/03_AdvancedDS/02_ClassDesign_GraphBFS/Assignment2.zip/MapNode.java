package roadgraph;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import geography.GeographicPoint;

public class MapNode {
	private GeographicPoint location = null;
	private List<MapEdge> inEdges = null;
	private List<MapEdge> outEdges = null;

	public MapNode(GeographicPoint location) {
		super();
		this.location = location;
		this.inEdges = new ArrayList<MapEdge>();
		this.outEdges = new ArrayList<MapEdge>();
	}

	public GeographicPoint getLocation() {
		return location;
	}

	public List<MapEdge> getInEdges() {
		return new ArrayList<MapEdge>(this.inEdges);
	}

	public void addInEdge(MapEdge inEdge) {
		this.inEdges.add(inEdge);
	}

	public List<MapEdge> getOutEdges() {
		return new ArrayList<MapEdge>(this.outEdges);
	}

	public int getNumOutEdges(){
		return this.outEdges.size();
	}
	
	public void addOutEdge(MapEdge outEdge) {
		this.outEdges.add(outEdge);
	}

	public int getTotalNumEdges() {
		return inEdges.size() + outEdges.size();
	}

	public Set<MapNode> getOutEdgeNodes(){
		Set<MapNode> connectedNodes = new HashSet<MapNode>();
		for (MapEdge outEdge: this.outEdges){
			connectedNodes.add(outEdge.getToNode());
		}
		return connectedNodes;
	}
	
	public String toString() {
		return "MapNode [location=" + location + ", inEdges=" + inEdges + ", outEdges=" + outEdges + "]";
	}

}
